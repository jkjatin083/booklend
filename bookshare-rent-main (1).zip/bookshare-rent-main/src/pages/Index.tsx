import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { BookCard } from "@/components/BookCard";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ArrowRight, BookOpen, Coins, Users, Shield } from "lucide-react";

export default function Index() {
  const { data: featuredBooks, isLoading } = useQuery({
    queryKey: ["featured-books"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("books")
        .select("*")
        .eq("is_available", true)
        .order("created_at", { ascending: false })
        .limit(4);

      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="min-h-screen flex flex-col bg-gradient-hero">
      <Navbar />

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="font-serif text-5xl md:text-7xl font-bold mb-6 animate-fade-up text-foreground leading-tight">
              Share Books,{" "}
              <span className="text-gradient">Earn Daily</span>
            </h1>
            <p
              className="text-xl md:text-2xl text-muted-foreground mb-8 animate-fade-up max-w-2xl mx-auto"
              style={{ animationDelay: "0.1s" }}
            >
              Turn your bookshelf into a source of income. Rent out your books
              to fellow readers and earn money every day.
            </p>
            <div
              className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-up"
              style={{ animationDelay: "0.2s" }}
            >
              <Button variant="hero" size="xl" asChild>
                <Link to="/books">
                  Browse Books
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </Button>
              <Button variant="outline" size="xl" asChild>
                <Link to="/auth?mode=signup">Start Lending</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-card">
        <div className="container mx-auto">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-center mb-12">
            How It Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center p-6 animate-fade-up">
              <div className="w-16 h-16 rounded-2xl bg-gradient-warm flex items-center justify-center mx-auto mb-4 shadow-warm">
                <BookOpen className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="font-serif text-xl font-semibold mb-2">
                List Your Books
              </h3>
              <p className="text-muted-foreground">
                Add your books to the platform with daily rental rates you set.
              </p>
            </div>
            <div
              className="text-center p-6 animate-fade-up"
              style={{ animationDelay: "0.1s" }}
            >
              <div className="w-16 h-16 rounded-2xl bg-gradient-warm flex items-center justify-center mx-auto mb-4 shadow-warm">
                <Users className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="font-serif text-xl font-semibold mb-2">
                Connect with Readers
              </h3>
              <p className="text-muted-foreground">
                Readers browse and rent your books for the duration they need.
              </p>
            </div>
            <div
              className="text-center p-6 animate-fade-up"
              style={{ animationDelay: "0.2s" }}
            >
              <div className="w-16 h-16 rounded-2xl bg-gradient-warm flex items-center justify-center mx-auto mb-4 shadow-warm">
                <Coins className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="font-serif text-xl font-semibold mb-2">
                Earn Daily
              </h3>
              <p className="text-muted-foreground">
                Get paid for every day your book is rented out to readers.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Books Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-serif text-3xl font-bold">Featured Books</h2>
            <Button variant="ghost" asChild>
              <Link to="/books">
                View All
                <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
            </Button>
          </div>
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div
                  key={i}
                  className="aspect-[3/4] rounded-xl bg-muted animate-pulse"
                />
              ))}
            </div>
          ) : featuredBooks && featuredBooks.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredBooks.map((book) => (
                <BookCard
                  key={book.id}
                  id={book.id}
                  title={book.title}
                  author={book.author}
                  coverImage={book.cover_image || undefined}
                  dailyRate={Number(book.daily_rate)}
                  condition={book.condition || undefined}
                  location={book.location || undefined}
                  genre={book.genre || undefined}
                  isAvailable={book.is_available ?? true}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-card rounded-xl border border-border">
              <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-serif text-xl font-semibold mb-2">
                No Books Yet
              </h3>
              <p className="text-muted-foreground mb-4">
                Be the first to list your books on BookLend!
              </p>
              <Button variant="hero" asChild>
                <Link to="/add-book">Add Your First Book</Link>
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-20 px-4 bg-card">
        <div className="container mx-auto max-w-4xl text-center">
          <div className="w-16 h-16 rounded-2xl bg-accent flex items-center justify-center mx-auto mb-6">
            <Shield className="w-8 h-8 text-accent-foreground" />
          </div>
          <h2 className="font-serif text-3xl md:text-4xl font-bold mb-4">
            Safe & Secure Lending
          </h2>
          <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
            Our platform connects verified readers with book owners. Track your
            rentals, manage your earnings, and build trust within our community.
          </p>
          <Button variant="hero" size="lg" asChild>
            <Link to="/auth?mode=signup">Join BookLend Today</Link>
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
}
