import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useToast } from "@/hooks/use-toast";
import { format, differenceInDays } from "date-fns";
import { MapPin, User, Calendar as CalendarIcon, BookOpen, ArrowLeft, Loader2, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { UPIPayment } from "@/components/UPIPayment";

const conditionLabels: Record<string, string> = {
  new: "New",
  like_new: "Like New",
  good: "Good",
  fair: "Fair",
  poor: "Poor",
};

export default function BookDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [showPayment, setShowPayment] = useState(false);

  const { data: book, isLoading } = useQuery({
    queryKey: ["book", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("books")
        .select("*")
        .eq("id", id)
        .maybeSingle();

      if (error) throw error;
      return data;
    },
    enabled: !!id,
  });

  const rentalMutation = useMutation({
    mutationFn: async (transactionId: string) => {
      if (!user || !startDate || !endDate || !book) {
        throw new Error("Missing required data");
      }

      const days = differenceInDays(endDate, startDate) + 1;
      const totalAmount = days * Number(book.daily_rate);

      const { error } = await supabase.from("rentals").insert({
        book_id: book.id,
        renter_id: user.id,
        start_date: format(startDate, "yyyy-MM-dd"),
        end_date: format(endDate, "yyyy-MM-dd"),
        total_amount: totalAmount,
        status: "confirmed",
      });

      if (error) throw error;

      // Update book availability
      await supabase.from("books").update({ is_available: false }).eq("id", book.id);
    },
    onSuccess: () => {
      toast({
        title: "Payment Confirmed!",
        description: "Your book rental has been confirmed.",
      });
      queryClient.invalidateQueries({ queryKey: ["book", id] });
      navigate("/my-rentals");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to confirm payment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleProceedToPayment = () => {
    if (!user) {
      navigate("/auth");
      return;
    }
    if (!startDate || !endDate) {
      toast({
        title: "Select Dates",
        description: "Please select both start and end dates for your rental.",
        variant: "destructive",
      });
      return;
    }
    setShowPayment(true);
  };

  const handlePaymentConfirm = (transactionId: string) => {
    rentalMutation.mutate(transactionId);
  };

  const rentalDays = startDate && endDate ? differenceInDays(endDate, startDate) + 1 : 0;
  const totalCost = book ? rentalDays * Number(book.daily_rate) : 0;

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-1 pt-24 pb-12 px-4 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </main>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-1 pt-24 pb-12 px-4">
          <div className="container mx-auto text-center py-16">
            <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="font-serif text-2xl font-semibold mb-2">Book Not Found</h2>
            <p className="text-muted-foreground mb-6">
              This book may have been removed or doesn't exist.
            </p>
            <Button variant="hero" onClick={() => navigate("/books")}>
              Browse Other Books
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const isOwner = user?.id === book.owner_id;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <main className="flex-1 pt-24 pb-12 px-4">
        <div className="container mx-auto">
          <Button
            variant="ghost"
            className="mb-6"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Book Image */}
            <div className="relative aspect-[3/4] rounded-xl overflow-hidden bg-muted shadow-elevated">
              {book.cover_image ? (
                <img
                  src={book.cover_image}
                  alt={book.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-secondary to-muted">
                  <span className="font-serif text-8xl text-muted-foreground/30">
                    {book.title.charAt(0)}
                  </span>
                </div>
              )}
              {!book.is_available && (
                <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                  <Badge variant="secondary" className="text-lg py-2 px-4">
                    Currently Rented
                  </Badge>
                </div>
              )}
            </div>

            {/* Book Details */}
            <div className="space-y-6">
              <div>
                {book.genre && (
                  <Badge className="mb-3">{book.genre}</Badge>
                )}
                <h1 className="font-serif text-4xl font-bold mb-2">
                  {book.title}
                </h1>
                <p className="text-xl text-muted-foreground">by {book.author}</p>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-3xl font-bold text-primary">
                  ₹{Number(book.daily_rate).toFixed(0)}
                  <span className="text-lg font-normal text-muted-foreground">
                    /day
                  </span>
                </div>
                {book.condition && (
                  <Badge variant="outline" className="text-sm">
                    {conditionLabels[book.condition]}
                  </Badge>
                )}
              </div>

              {/* Borrow Now Button - Quick Action */}
              {!isOwner && book.is_available && (
                <Button
                  variant="hero"
                  size="xl"
                  className="w-full md:w-auto group relative overflow-hidden"
                  onClick={() => {
                    if (!user) {
                      navigate("/auth");
                      return;
                    }
                    const rentalCard = document.getElementById("rental-card");
                    rentalCard?.scrollIntoView({ behavior: "smooth" });
                  }}
                >
                  <Sparkles className="w-5 h-5 transition-transform group-hover:rotate-12" />
                  <span>Borrow Now</span>
                  <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-500 skew-x-12" />
                </Button>
              )}

              {book.description && (
                <div>
                  <h3 className="font-serif font-semibold mb-2">Description</h3>
                  <p className="text-muted-foreground">{book.description}</p>
                </div>
              )}

              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <User className="w-4 h-4" />
                  <span>Available for rent</span>
                </div>
                {book.location && (
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    <span>{book.location}</span>
                  </div>
                )}
              </div>

              {/* Rental Card */}
              {!isOwner && book.is_available && (
                <Card className="mt-8" id="rental-card">
                  <CardHeader>
                    <CardTitle className="font-serif">Borrow This Book</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Start Date
                        </label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full justify-start text-left font-normal",
                                !startDate && "text-muted-foreground"
                              )}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {startDate ? format(startDate, "PPP") : "Pick date"}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={startDate}
                              onSelect={setStartDate}
                              disabled={(date) => date < new Date()}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          End Date
                        </label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full justify-start text-left font-normal",
                                !endDate && "text-muted-foreground"
                              )}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {endDate ? format(endDate, "PPP") : "Pick date"}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={endDate}
                              onSelect={setEndDate}
                              disabled={(date) =>
                                date < new Date() ||
                                (startDate ? date < startDate : false)
                              }
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                    </div>

                    {rentalDays > 0 && !showPayment && (
                      <div className="bg-secondary/50 rounded-lg p-4">
                        <div className="flex justify-between mb-2">
                          <span className="text-muted-foreground">
                            ₹{Number(book.daily_rate).toFixed(0)} × {rentalDays} days
                          </span>
                          <span className="font-medium">
                            ₹{totalCost.toFixed(0)}
                          </span>
                        </div>
                        <div className="flex justify-between font-semibold text-lg border-t border-border pt-2">
                          <span>Total</span>
                          <span className="text-primary">
                            ₹{totalCost.toFixed(0)}
                          </span>
                        </div>
                      </div>
                    )}

                    {!showPayment ? (
                      <Button
                        variant="hero"
                        size="xl"
                        className="w-full group relative overflow-hidden"
                        onClick={handleProceedToPayment}
                        disabled={!startDate || !endDate}
                      >
                        <Sparkles className="w-5 h-5 transition-transform group-hover:rotate-12" />
                        <span>{user ? "Proceed to Payment" : "Sign In to Borrow"}</span>
                        <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-500 skew-x-12" />
                      </Button>
                    ) : (
                      <div className="space-y-4">
                        <UPIPayment
                          amount={totalCost}
                          onPaymentConfirm={handlePaymentConfirm}
                          isProcessing={rentalMutation.isPending}
                        />
                        <Button
                          variant="ghost"
                          className="w-full"
                          onClick={() => setShowPayment(false)}
                        >
                          Back to Dates
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {isOwner && (
                <Card className="bg-secondary/50">
                  <CardContent className="pt-6">
                    <p className="text-muted-foreground text-center">
                      This is your book. You can manage it from{" "}
                      <a href="/my-books" className="text-primary hover:underline">
                        My Books
                      </a>
                      .
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
