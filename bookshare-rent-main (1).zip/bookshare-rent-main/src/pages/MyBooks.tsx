import { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Plus, BookOpen, Trash2, Eye, Loader2 } from "lucide-react";

export default function MyBooks() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  const { data: books, isLoading } = useQuery({
    queryKey: ["my-books", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("books")
        .select("*")
        .eq("owner_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const deleteMutation = useMutation({
    mutationFn: async (bookId: string) => {
      const { error } = await supabase.from("books").delete().eq("id", bookId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Book Deleted",
        description: "Your book has been removed from listings.",
      });
      queryClient.invalidateQueries({ queryKey: ["my-books"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete book. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <main className="flex-1 pt-24 pb-12 px-4">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="font-serif text-4xl font-bold mb-2">My Books</h1>
              <p className="text-muted-foreground">
                Manage your listed books and track rentals
              </p>
            </div>
            <Button variant="hero" asChild>
              <Link to="/add-book">
                <Plus className="w-4 h-4" />
                Add Book
              </Link>
            </Button>
          </div>

          {books && books.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {books.map((book) => (
                <Card key={book.id} className="overflow-hidden">
                  <div className="flex">
                    <div className="w-24 h-32 flex-shrink-0 bg-muted">
                      {book.cover_image ? (
                        <img
                          src={book.cover_image}
                          alt={book.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-secondary to-muted">
                          <span className="font-serif text-2xl text-muted-foreground/50">
                            {book.title.charAt(0)}
                          </span>
                        </div>
                      )}
                    </div>
                    <CardContent className="flex-1 p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-serif font-semibold truncate">
                            {book.title}
                          </h3>
                          <p className="text-sm text-muted-foreground truncate">
                            {book.author}
                          </p>
                        </div>
                        <Badge
                          variant={book.is_available ? "default" : "secondary"}
                          className="ml-2 flex-shrink-0"
                        >
                          {book.is_available ? "Available" : "Rented"}
                        </Badge>
                      </div>
                      <p className="text-primary font-bold mt-2">
                        ${Number(book.daily_rate).toFixed(2)}/day
                      </p>
                      <div className="flex gap-2 mt-3">
                        <Button
                          variant="outline"
                          size="sm"
                          asChild
                          className="flex-1"
                        >
                          <Link to={`/books/${book.id}`}>
                            <Eye className="w-3 h-3 mr-1" />
                            View
                          </Link>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-destructive hover:text-destructive"
                          onClick={() => {
                            if (confirm("Are you sure you want to delete this book?")) {
                              deleteMutation.mutate(book.id);
                            }
                          }}
                          disabled={deleteMutation.isPending}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-card rounded-xl border border-border">
              <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-serif text-2xl font-semibold mb-2">
                No Books Yet
              </h3>
              <p className="text-muted-foreground mb-6">
                Start earning by listing your first book!
              </p>
              <Button variant="hero" asChild>
                <Link to="/add-book">
                  <Plus className="w-4 h-4" />
                  Add Your First Book
                </Link>
              </Button>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
