import { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { BookOpen, Calendar, Loader2, Check, X, RotateCcw, Undo2 } from "lucide-react";

const statusColors: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800",
  confirmed: "bg-green-100 text-green-800",
  active: "bg-green-100 text-green-800",
  completed: "bg-blue-100 text-blue-800",
  cancelled: "bg-red-100 text-red-800",
};

export default function MyRentals() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  // Rentals where user is the renter
  const { data: myRentals, isLoading: rentalsLoading } = useQuery({
    queryKey: ["my-rentals", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("rentals")
        .select("*, books(*)")
        .eq("renter_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  // Rental requests for user's books
  const { data: rentalRequests, isLoading: requestsLoading } = useQuery({
    queryKey: ["rental-requests", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("rentals")
        .select("*, books!inner(*)")
        .eq("books.owner_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const updateRentalMutation = useMutation({
    mutationFn: async ({
      rentalId,
      status,
      bookId,
    }: {
      rentalId: string;
      status: string;
      bookId: string;
    }) => {
      const { error } = await supabase
        .from("rentals")
        .update({ status })
        .eq("id", rentalId);

      if (error) throw error;

      // Update book availability based on status
      if (status === "active" || status === "confirmed") {
        await supabase.from("books").update({ is_available: false }).eq("id", bookId);
      } else if (status === "completed" || status === "cancelled") {
        await supabase.from("books").update({ is_available: true }).eq("id", bookId);
      }
    },
    onSuccess: () => {
      toast({
        title: "Status Updated",
        description: "The rental status has been updated.",
      });
      queryClient.invalidateQueries({ queryKey: ["my-rentals"] });
      queryClient.invalidateQueries({ queryKey: ["rental-requests"] });
      queryClient.invalidateQueries({ queryKey: ["book"] });
      queryClient.invalidateQueries({ queryKey: ["books"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update rental status.",
        variant: "destructive",
      });
    },
  });

  if (authLoading || rentalsLoading || requestsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <main className="flex-1 pt-24 pb-12 px-4">
        <div className="container mx-auto">
          <div className="mb-8">
            <h1 className="font-serif text-4xl font-bold mb-2">My Rentals</h1>
            <p className="text-muted-foreground">
              Track your book rentals and manage requests
            </p>
          </div>

          <Tabs defaultValue="my-rentals">
            <TabsList className="mb-6">
              <TabsTrigger value="my-rentals">Books I'm Renting</TabsTrigger>
              <TabsTrigger value="requests">
                Rental Requests
                {rentalRequests && rentalRequests.filter((r) => r.status === "pending").length > 0 && (
                  <Badge className="ml-2" variant="default">
                    {rentalRequests.filter((r) => r.status === "pending").length}
                  </Badge>
                )}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="my-rentals">
              {myRentals && myRentals.length > 0 ? (
                <div className="space-y-4">
                  {myRentals.map((rental) => (
                    <Card key={rental.id}>
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row gap-4">
                          <div className="w-20 h-28 flex-shrink-0 rounded-lg overflow-hidden bg-muted">
                            {rental.books?.cover_image ? (
                              <img
                                src={rental.books.cover_image}
                                alt={rental.books.title}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <BookOpen className="w-8 h-8 text-muted-foreground" />
                              </div>
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <Link
                                  to={`/books/${rental.book_id}`}
                                  className="font-serif text-lg font-semibold hover:text-primary transition-colors"
                                >
                                  {rental.books?.title}
                                </Link>
                                <p className="text-muted-foreground text-sm">
                                  by {rental.books?.author}
                                </p>
                              </div>
                              <Badge className={statusColors[rental.status || "pending"]}>
                                {rental.status}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                {format(new Date(rental.start_date), "MMM d")} -{" "}
                                {rental.end_date
                                  ? format(new Date(rental.end_date), "MMM d, yyyy")
                                  : "Ongoing"}
                              </div>
                            </div>
                            <p className="text-primary font-bold mt-2">
                              Total: ₹{Number(rental.total_amount || 0).toFixed(0)}
                            </p>
                            
                            {(rental.status === "active" || rental.status === "confirmed") && (
                              <Button
                                size="default"
                                className="mt-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] group"
                                onClick={() =>
                                  updateRentalMutation.mutate({
                                    rentalId: rental.id,
                                    status: "completed",
                                    bookId: rental.book_id,
                                  })
                                }
                                disabled={updateRentalMutation.isPending}
                              >
                                {updateRentalMutation.isPending ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                  <Undo2 className="w-4 h-4 transition-transform group-hover:-rotate-45" />
                                )}
                                Return Book
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16 bg-card rounded-xl border border-border">
                  <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-serif text-2xl font-semibold mb-2">
                    No Rentals Yet
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    Start browsing and rent your first book!
                  </p>
                  <Button variant="hero" asChild>
                    <Link to="/books">Browse Books</Link>
                  </Button>
                </div>
              )}
            </TabsContent>

            <TabsContent value="requests">
              {rentalRequests && rentalRequests.length > 0 ? (
                <div className="space-y-4">
                  {rentalRequests.map((rental) => (
                    <Card key={rental.id}>
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row gap-4">
                          <div className="w-20 h-28 flex-shrink-0 rounded-lg overflow-hidden bg-muted">
                            {rental.books?.cover_image ? (
                              <img
                                src={rental.books.cover_image}
                                alt={rental.books.title}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <BookOpen className="w-8 h-8 text-muted-foreground" />
                              </div>
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                              <h3 className="font-serif text-lg font-semibold">
                                  {rental.books?.title}
                                </h3>
                                <p className="text-muted-foreground text-sm">
                                  Rental Request
                                </p>
                              </div>
                              <Badge className={statusColors[rental.status || "pending"]}>
                                {rental.status}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                {format(new Date(rental.start_date), "MMM d")} -{" "}
                                {rental.end_date
                                  ? format(new Date(rental.end_date), "MMM d, yyyy")
                                  : "Ongoing"}
                              </div>
                            </div>
                            <p className="text-primary font-bold mt-2">
                              Earnings: ₹{Number(rental.total_amount || 0).toFixed(0)}
                            </p>

                            {rental.status === "pending" && (
                              <div className="flex gap-2 mt-4">
                                <Button
                                  variant="hero"
                                  size="sm"
                                  onClick={() =>
                                    updateRentalMutation.mutate({
                                      rentalId: rental.id,
                                      status: "active",
                                      bookId: rental.book_id,
                                    })
                                  }
                                  disabled={updateRentalMutation.isPending}
                                >
                                  <Check className="w-4 h-4" />
                                  Approve
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    updateRentalMutation.mutate({
                                      rentalId: rental.id,
                                      status: "cancelled",
                                      bookId: rental.book_id,
                                    })
                                  }
                                  disabled={updateRentalMutation.isPending}
                                >
                                  <X className="w-4 h-4" />
                                  Decline
                                </Button>
                              </div>
                            )}

                            {(rental.status === "active" || rental.status === "confirmed") && (
                              <Button
                                size="default"
                                className="mt-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] group"
                                onClick={() =>
                                  updateRentalMutation.mutate({
                                    rentalId: rental.id,
                                    status: "completed",
                                    bookId: rental.book_id,
                                  })
                                }
                                disabled={updateRentalMutation.isPending}
                              >
                                {updateRentalMutation.isPending ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                  <Check className="w-4 h-4 transition-transform group-hover:scale-110" />
                                )}
                                Mark as Returned
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16 bg-card rounded-xl border border-border">
                  <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-serif text-2xl font-semibold mb-2">
                    No Rental Requests
                  </h3>
                  <p className="text-muted-foreground">
                    When someone requests to rent your books, they'll appear here.
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  );
}
