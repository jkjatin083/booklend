import { useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Smartphone, Copy, Check, IndianRupee } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface UPIPaymentProps {
  amount: number;
  upiId?: string;
  onPaymentConfirm: (transactionId: string) => void;
  isProcessing?: boolean;
}

export function UPIPayment({ 
  amount, 
  upiId = "bookrent@upi", 
  onPaymentConfirm,
  isProcessing 
}: UPIPaymentProps) {
  const [transactionId, setTransactionId] = useState("");
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const upiLink = `upi://pay?pa=${upiId}&pn=BookRent&am=${amount}&cu=INR&tn=Book%20Rental%20Payment`;

  const handleCopyUPI = () => {
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    toast({
      title: "UPI ID Copied!",
      description: "Paste it in your UPI app to pay.",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePayNow = () => {
    window.location.href = upiLink;
  };

  const handleConfirmPayment = () => {
    if (!transactionId.trim()) {
      toast({
        title: "Enter Transaction ID",
        description: "Please enter the UPI transaction ID after payment.",
        variant: "destructive",
      });
      return;
    }
    onPaymentConfirm(transactionId);
  };

  return (
    <Card className="border-2 border-primary/20 bg-gradient-to-br from-background to-secondary/30">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="font-serif flex items-center gap-2">
            <IndianRupee className="w-5 h-5 text-primary" />
            Pay via UPI
          </CardTitle>
          <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/30">
            Instant
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Amount Display */}
        <div className="text-center p-4 bg-primary/5 rounded-xl">
          <p className="text-sm text-muted-foreground mb-1">Amount to Pay</p>
          <p className="text-4xl font-bold text-primary">₹{amount.toFixed(0)}</p>
        </div>

        {/* UPI Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Pay with UPI App */}
          <div className="space-y-3">
            <p className="text-sm font-medium text-center">Pay with UPI App</p>
            <Button
              variant="outline"
              className="w-full h-14 gap-3 hover:bg-primary/5 hover:border-primary/50 transition-all"
              onClick={handlePayNow}
            >
              <Smartphone className="w-5 h-5 text-primary" />
              <span>Open UPI App</span>
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              GPay, PhonePe, Paytm, etc.
            </p>
          </div>

          {/* Copy UPI ID */}
          <div className="space-y-3">
            <p className="text-sm font-medium text-center">Or Copy UPI ID</p>
            <Button
              variant="outline"
              className="w-full h-14 gap-3 hover:bg-primary/5 hover:border-primary/50 transition-all group"
              onClick={handleCopyUPI}
            >
              {copied ? (
                <Check className="w-5 h-5 text-green-500" />
              ) : (
                <Copy className="w-5 h-5 text-primary group-hover:scale-110 transition-transform" />
              )}
              <span className="font-mono text-sm">{upiId}</span>
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              Manually enter in your app
            </p>
          </div>
        </div>

        {/* QR Code */}
        <div className="flex flex-col items-center gap-3 p-4 bg-muted/50 rounded-xl">
          <div className="p-3 bg-white rounded-xl shadow-sm">
            <QRCodeSVG
              value={upiLink}
              size={140}
              level="H"
              includeMargin={false}
              bgColor="#ffffff"
              fgColor="#000000"
            />
          </div>
          <p className="text-sm font-medium text-foreground">Scan to Pay</p>
          <p className="text-xs text-muted-foreground text-center max-w-[200px]">
            Open any UPI app and scan this QR code
          </p>
        </div>

        {/* Transaction Confirmation */}
        <div className="space-y-3 pt-4 border-t border-border">
          <p className="text-sm font-medium">After Payment</p>
          <p className="text-xs text-muted-foreground">
            Enter the UPI Transaction ID / Reference Number from your payment app
          </p>
          <Input
            placeholder="e.g., 123456789012"
            value={transactionId}
            onChange={(e) => setTransactionId(e.target.value)}
            className="font-mono"
          />
          <Button
            variant="hero"
            size="lg"
            className="w-full"
            onClick={handleConfirmPayment}
            disabled={isProcessing || !transactionId.trim()}
          >
            {isProcessing ? "Confirming..." : "Confirm Payment"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
