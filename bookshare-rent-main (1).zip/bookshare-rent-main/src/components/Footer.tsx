import { Link } from "react-router-dom";
import { BookOpen, Heart } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-card border-t border-border py-12 mt-auto">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-warm flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-serif text-xl font-semibold">BookLend</span>
            </Link>
            <p className="text-muted-foreground max-w-md">
              Share your books, earn while you read. Join our community of book
              lovers and make your library work for you.
            </p>
          </div>

          <div>
            <h4 className="font-serif font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link
                  to="/books"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Browse Books
                </Link>
              </li>
              <li>
                <Link
                  to="/add-book"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  List Your Book
                </Link>
              </li>
              <li>
                <Link
                  to="/auth"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Sign In
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-serif font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              <li>
                <span className="text-muted-foreground">How it Works</span>
              </li>
              <li>
                <span className="text-muted-foreground">FAQs</span>
              </li>
              <li>
                <span className="text-muted-foreground">Contact Us</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} BookLend. All rights reserved.
          </p>
          <p className="text-muted-foreground text-sm flex items-center gap-1">
            Made with <Heart className="w-4 h-4 text-primary" /> for book lovers
          </p>
        </div>
      </div>
    </footer>
  );
}
