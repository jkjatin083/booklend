import { Link, useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, HandHeart } from "lucide-react";

interface BookCardProps {
  id: string;
  title: string;
  author: string;
  coverImage?: string;
  dailyRate: number;
  condition?: string;
  location?: string;
  genre?: string;
  isAvailable?: boolean;
  showLendButton?: boolean;
}

const conditionLabels: Record<string, string> = {
  new: "New",
  like_new: "Like New",
  good: "Good",
  fair: "Fair",
  poor: "Poor",
};

export function BookCard({
  id,
  title,
  author,
  coverImage,
  dailyRate,
  condition,
  location,
  genre,
  isAvailable = true,
  showLendButton = false,
}: BookCardProps) {
  const navigate = useNavigate();

  const handleLendClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    navigate("/add-book");
  };

  return (
    <Link to={`/books/${id}`}>
      <Card className="group overflow-hidden h-full cursor-pointer hover:scale-[1.02] transition-transform duration-300">
        <div className="relative aspect-[3/4] overflow-hidden bg-muted">
          {coverImage ? (
            <img
              src={coverImage}
              alt={title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-secondary to-muted">
              <span className="font-serif text-4xl text-muted-foreground/50">
                {title.charAt(0)}
              </span>
            </div>
          )}
          {!isAvailable && (
            <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
              <Badge variant="secondary" className="text-sm">
                Currently Rented
              </Badge>
            </div>
          )}
          {genre && (
            <Badge className="absolute top-3 left-3 bg-background/90 text-foreground backdrop-blur-sm">
              {genre}
            </Badge>
          )}
        </div>
        <CardContent className="p-4">
          <h3 className="font-serif text-lg font-semibold line-clamp-1 mb-1">
            {title}
          </h3>
          <p className="text-muted-foreground text-sm mb-3">{author}</p>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <span className="text-primary font-bold text-lg">
                ₹{dailyRate.toFixed(0)}
              </span>
              <span className="text-muted-foreground text-sm">/day</span>
            </div>
            {condition && (
              <Badge variant="outline" className="text-xs">
                {conditionLabels[condition] || condition}
              </Badge>
            )}
          </div>

          {location && (
            <div className="flex items-center gap-1 mt-2 text-muted-foreground text-sm">
              <MapPin className="w-3 h-3" />
              <span className="truncate">{location}</span>
            </div>
          )}

          {showLendButton && (
            <Button
              variant="hero"
              size="sm"
              className="w-full mt-3"
              onClick={handleLendClick}
            >
              <HandHeart className="w-4 h-4 mr-2" />
              Lend a Book
            </Button>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
